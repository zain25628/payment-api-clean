# Refactored by Copilot
# dependencies package initializer

from .deps import *  # noqa: F401,F403

__all__ = ["deps"]
