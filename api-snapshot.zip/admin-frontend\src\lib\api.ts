import axios from 'axios'
import {
  AdminCountry,
  AdminCountryWithProviders,
  AdminCompanyListItem,
  AdminCompanyOut,
  AdminCompanyCreatePayload
} from './types'

const client = axios.create({ baseURL: 'http://localhost:8000' })

export async function fetchCountries(): Promise<AdminCountry[]> {
  const resp = await client.get('/admin/geo/countries')
  return resp.data
}

export async function fetchCountryWithProviders(code: string): Promise<AdminCountryWithProviders> {
  const resp = await client.get(`/admin/geo/countries/${code}/providers`)
  return resp.data
}

export async function fetchCompanies(): Promise<AdminCompanyListItem[]> {
  const resp = await client.get('/admin/companies')
  return resp.data
}

export async function createCompany(payload: AdminCompanyCreatePayload): Promise<AdminCompanyOut> {
  const resp = await client.post('/admin/companies', payload)
  return resp.data
}

export async function getCompany(id: number): Promise<AdminCompanyOut> {
  const resp = await client.get(`/admin/companies/${id}`)
  return resp.data
}

export async function updateCompany(id: number, payload: AdminCompanyCreatePayload): Promise<AdminCompanyOut> {
  const resp = await client.put(`/admin/companies/${id}`, payload)
  return resp.data
}

export async function toggleCompany(id: number): Promise<AdminCompanyOut> {
  const resp = await client.post(`/admin/companies/${id}/toggle`)
  return resp.data
}
