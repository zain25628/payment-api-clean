import React from 'react'
import { NavLink } from 'react-router-dom'

const NavItem: React.FC<{to:string, children: React.ReactNode}> = ({to, children}) => (
  <NavLink to={to} className={({isActive}) => `px-3 py-2 rounded ${isActive? 'bg-gray-200' : 'hover:bg-gray-100'}`}>
    {children}
  </NavLink>
)

const Layout: React.FC<{children: React.ReactNode}> = ({children}) => {
  return (
    <div className="min-h-screen flex">
      <aside className="w-64 bg-white border-r">
        <div className="p-4 font-bold">Admin Dashboard</div>
        <nav className="p-4 space-y-2">
          <NavItem to="/companies">Companies</NavItem>
          <NavItem to="/companies/new">Create Company</NavItem>
        </nav>
      </aside>
      <main className="flex-1 p-6">
        {children}
      </main>
    </div>
  )
}

export default Layout
