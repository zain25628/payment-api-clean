export type AdminCountry = {
  id: number
  code: string
  name: string
}

export type AdminPaymentProvider = {
  id: number
  code: string
  name: string
  description?: string | null
}

export type AdminCountryWithProviders = {
  country: AdminCountry
  providers: AdminPaymentProvider[]
}

export type AdminChannelOut = {
  id: number
  name: string
  provider_code: string
  channel_api_key?: string | null
  is_active: boolean
}

export type AdminCompanyListItem = {
  id: number
  name: string
  country_code?: string | null
  is_active: boolean
}

export type AdminCompanyOut = {
  id: number
  name: string
  api_key?: string | null
  country_code?: string | null
  telegram_bot_token?: string | null
  telegram_default_group_id?: string | null
  is_active: boolean
  channels: AdminChannelOut[]
}

export type AdminCompanyCreatePayload = {
  name: string
  country_code?: string | null
  telegram_bot_token?: string | null
  telegram_default_group_id?: string | null
  provider_codes?: string[]
}
